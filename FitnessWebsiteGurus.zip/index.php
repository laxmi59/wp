<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 */

get_header(); ?>
<?php get_sidebar(); ?>
		<div id="primary">
			<div id="content" role="main">
 			<section class="title">
			<?php $home_title=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."posts where post_name='home-headline'"));?>
				<h1><?php echo $home_title->post_content?></h1>
			<?php $home_subtitle=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."posts where post_name='home-sub-headline'"));?>
				<h2><?php echo $home_subtitle->post_content?></h2>
				<div class="titlehline"></div>
			</section>
			<div>
			<?php $home_subtitle=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."posts where post_name='home-body'"));?>
				<?php echo $home_subtitle->post_content?>
			</div>
			<!--<div class="intro-txt">
			Dear Reader,<BR><BR>
			<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc bibendum lectus eu sapien scelerisque nec elementum neque congue. Vestibulum id gravida enim. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla facilisi. Vestibulum varius cursus dictum. Suspendisse pretium erat in nisi varius id viverra neque fermentum. Nunc eget justo et nisi accumsan vehicula. Mauris in neque in leo mattis semper eget vel dui. Vestibulum rutrum mi eu diam lobortis blandit. Pellentesque bibendum, sem a ornare facilisis, leo nunc scelerisque tortor, nec blandit quam urna ut risus. Nulla facilisis venenatis varius. Donec eleifend, mi vel lacinia sodales, ante orci consectetur est, sed ullamcorper enim augue nec sapien. Curabitur aliquet pulvinar quam, id rhoncus nisi tempus at.
Fusce auctor orci imperdiet ipsum ornare eget commodo nunc pretium. Ut vehicula eleifend sapien placerat semper. Nulla rutrum dui erat, sed posuere turpis. Cras ac erat non nisi vulputate luctus. Quisque metus eros, semper quis dictum non, tincidunt nec sapien. Maecenas ut ligula vel mauris pulvinar faucibus a iaculis eros. Donec porta hendrerit augue, a pellentesque lorem placerat at. Aliquam sit amet dolor eros. Nulla facilisi. Fusce vitae lectus massa. Phasellus eget urna nisi, at interdum augue. Praesent sit amet lectus id neque suscipit hendrerit. Aenean sed metus ipsum, at sollicitudin felis. Curabitur a augue neque, quis condimentum nulla. </p>
			</div>
			<section class="tstimonial"> 
					<ul>
					<li><h2>Nothing Beats John Dane's Fitness Instructions! I love it! </h2><div class="qoote"></div> 
					 <?php //echo '<img src="'.WP_CONTENT_URL. '/uploads/2012/04/before-after-pic.png"/>'; ?>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque volutpat nulla vel tortor euismod quis malesuada dui cursus. Nulla interdum metus vitae felis vulputate dapibus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
					<strong>Jason Bourne</strong><br>
California </li> 
					</ul><div class="shadow"></div>
			</section>
			<section class="tstimonial"> 
					<ul>
					<li><h2>Effective Instructions and State of the Art Equipments!</h2><div class="qoote"></div> 
					 <?php //echo '<img src="'.WP_CONTENT_URL. '/uploads/2012/04/test-pic.png"/>'; ?>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque volutpat nulla vel tortor euismod quis malesuada dui cursus. Nulla interdum metus vitae felis vulputate dapibus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. </p>
					<strong>Jason Bourne</strong><br>
California </li> 
					</ul><div class="shadow"></div>
			</section>-->
			</div><!-- #content -->
		</div><!-- #primary -->
<?php get_footer(); ?>