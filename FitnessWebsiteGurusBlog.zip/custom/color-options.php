<?php
//global $wpdb;
include("functions.php");
if($_GET['act']=='setColor'){
	echo setasFeaturedColor($_GET['id']);
}
?>
<script type="text/javascript">
function setThisColor(id){
//alert("tt");
	var r=confirm("Do You Want set this Color?");
	if (r==true){
		window.location='admin.php?page=theme-options&act=setColor&id='+id;
	}else{
		window.location='admin.php?page=theme-options';
	}
}
</script>
<style type="text/css">
.theme-options-table{} 
.theme-options-table td{ padding-left:10px} 
</style>
<div>&nbsp;</div>
<?php echo getColorOptions();?>
<br>
