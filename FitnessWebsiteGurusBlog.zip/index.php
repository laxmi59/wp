<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 */

get_header(); ?>
<?php get_sidebar(); ?>
		<div id="primary">
			<div id="content" role="main">

			<?php
		 // for pagination
		//echo "SELECT `option_name` , `option_value` FROM  `".$wpdb->prefix."options` WHERE `option_name` = 'posts_per_page' ";
		 $pagenate=mysql_fetch_object(mysql_query("SELECT `option_name` , `option_value` FROM  `".$wpdb->prefix."options` WHERE `option_name` = 'posts_per_page' "));
		if($paged =='0') $start=0; else $start=($paged-1)*$pagenate->option_value;
		//echo $start;
		 $p_limit=$pagenate->option_value;
		 $qry="SELECT * FROM `".$wpdb->prefix."posts` WHERE post_status = 'publish' AND post_type = 'post' order by post_date desc";
		 $num=mysql_num_rows(mysql_query($qry));
		 $page_numbers=round($num /4);
		 $getArticles=mysql_query("SELECT * FROM `".$wpdb->prefix."posts` WHERE post_status = 'publish' AND post_type = 'post' order by post_date desc LIMIT $start , $p_limit");
		 $adcount=1;
		 if($paged){
		 	$postpos=$paged-1;
			$postpos=$postpos*3;
			$postpos=$postpos+1;
		 }else
			 $postpos=1;
		 while($fetArticles=mysql_fetch_object($getArticles)){
                     $getUserName=mysql_fetch_object(mysql_query("SELECT * FROM `".$wpdb->prefix."users` WHERE `ID` = $fetArticles->post_author"));
			 $authorName=$getUserName->display_name;
			 $post = new WP_Query('p='.$fetArticles->ID.'');
			 $post->the_post();
			 $category = get_the_category($fetArticles->ID);
			 $cont1 =get_post_custom_values('short_description', $fetArticles->ID); 
	if(strpos($cont1,'<img')!== FALSE) {
    	$img_start = strpos($cont1[0],'<img');
        $start = strpos($cont1[0],'src="',$img_start)+5;
        $end = strpos($cont1[0],'"',$start);
        $path = substr($cont1[0],$start,$end-$start);
    }
	$category = get_the_category($fetArticles->ID);
			 ?>
	
<article class="post-1 post type-post status-publish format-standard hentry category-uncategorized" id="post-1">
  <header class="entry-header">
    <h1 class="entry-title">
		<a rel="bookmark" title="Permalink to Title of Post Number One" href="<?php the_permalink(); ?>"><?php echo $fetArticles->post_title?></a> 
		<a rel="bookmark" title="12:22 pm" href="<?php the_permalink(); ?>"></a>
	</h1>
	<time pubdate="" datetime="<?php echo $fetArticles->post_dates?>" class="entry-date">
	
		<span class='day'><?php echo date('d',strtotime($fetArticles->post_date))?> </span>
		<span class='monthyear'>
			<span style="text-transform: uppercase;"><?php echo date('M',strtotime($fetArticles->post_date))?> </span>
			<span><?php echo date('Y',strtotime($fetArticles->post_date))?></span>
		</span>  
	</time>
    <div class="entry-meta"> 
	<span class="sep">Posted on </span>
	<span class="by-author"> 
		<span class="sep"> by </span> 
		<span class="author vcard"><a rel="author" title="View all posts by admin" href="<?php the_author_meta('user_url'); ?>" class="url fn n"><?php echo the_author_meta( 'user_nicename' ); ?></a></span>
	</span>  |  
	<div class="category">Category: <a href="category/<?php echo $category[0]->slug?>"><?php echo $category[0]->name?></a></div>  |   
	<div class="comments-link"> 
		<a href="<?php the_permalink(); ?>#comments"><span><?php echo $fetArticles->comment_count?> Comments</span></a> 
	</div> 
	</div> 
  </header>
  <!-- .entry-header -->
  <?php if($path <> ''){?>  <div class="feature-image"><img src="<?php echo $path ?>"></div><?php }?>
  <div class="entry-content">
    <p><?php echo get_the_excerpt()?></p> 
    
  </div> 
</article>
<?php }?>

			</div><!-- #content -->
			<div class="navigation"><?php if(function_exists('wp_paginate')) {
		wp_paginate();
	} ?>	</div> 
	
		</div><!-- #primary -->


<?php get_footer(); ?>