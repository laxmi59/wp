<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage FitnessWebsiteGurus-Blog
 */

get_header(); ?>
<?php get_sidebar(); ?>
		<div id="primary">
			<div id="content" role="main">

			<?php if ( have_posts() ) : ?>

				<?php twentyeleven_content_nav( 'nav-above' ); ?>

				<?php /* Start the Loop */ ?>
				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'content', get_post_format() ); ?>

				<?php endwhile; ?>

				<?php twentyeleven_content_nav( 'nav-below' ); ?>

			<?php else : ?>

				<article id="post-0" class="post no-results not-found">
					<header class="entry-header">
						<h1 class="entry-title"><?php _e( 'Nothing Found', 'twentyeleven' ); ?></h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
						<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'twentyeleven' ); ?></p>
						<?php get_search_form(); ?>
					</div><!-- .entry-content -->
				</article><!-- #post-0 -->

			<?php endif; ?>
	
<article class="post-1 post type-post status-publish format-standard hentry category-uncategorized" id="post-1">
  <header class="entry-header">
    <h1 class="entry-title"><a rel="bookmark" title="Permalink to Title of Post Number One" href="http://demo.fitnesswebsitegurus.com/?p=1">Title of Post Number One</a> <a rel="bookmark" title="12:22 pm" href="http://demo.fitnesswebsitegurus.com/?p=1"><time pubdate="" datetime="2012-04-19T12:22:24+00:00" class="entry-date">April 19, 2012</time></a></h1>
    <div class="entry-meta"> <span class="sep">Posted on </span><span class="by-author"> <span class="sep"> by </span> <span class="author vcard"><a rel="author" title="View all posts by admin" href="http://demo.fitnesswebsitegurus.com/?author=1" class="url fn n">admin</a></span></span>  |  <div class="category">Category: <a href="">Fitness Tips</a></div>  |   <div class="comments-link"> <a href="http://demo.fitnesswebsitegurus.com/?p=1#comments"><span>0141 Comments</span></a> </div> </div> 
  </header>
  <!-- .entry-header -->
  <div class="feature-image"><img src="<?php bloginfo( 'template_url' ); ?>/images/featured-img.png"></div>
  <div class="entry-content">
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi commodo, ipsum sed pharetra gravida, orci magna rhoncus neque, id pulvinar odio lorem non turpis. Nullam sit amet enim. Morbi commodo, ipsum sed pharetra gravida, orci magna rhoncus neque, id pulvinar odio lorem non turpis. Nullam sit amet enim.</p> 
    <div class="readmore">Read More</div>
  </div> 
</article>


			</div><!-- #content -->
	<div class="pager">
	<ul>
	<li><a class="prev" href="#"></a></li> 
	<li><a class="current" href="#">1</a></li> 
	<li><a href="#">2</a></li> 
	<li><a href="#">3</a></li> 
	<li><a href="#">4</a></li> 
	<li><a href="#">5</a></li> 
	<li><a href="#">6</a></li> 
	<li><a href="#">7</a></li> 
	<li><a href="#">...</a></li> 
	<li><a class="next" href="#"></a></li> 
	</ul>
	</div>
	
		</div><!-- #primary -->


<?php get_footer(); ?>