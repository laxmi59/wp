// JavaScript Document
alert("hi");
function trimfun(stringToTrim) {
	return stringToTrim.replace(/^\s+|\s+$/g,"");
}
function isNotEmpty(fname,txt){
	if(trimfun(fname.value)=="")	{
		alert(txt);
		fname.focus();
		return true;
	}
	return false;
}
function validateForm(reg){
	if(isNotEmpty(reg.product_title,"Title should not be Empty")){return false}
	if(isNotEmpty(reg.product_image,"Image should not be Empty")){return false}
}

function setAsFeatured(id,prefix){
	var r=confirm("Do You Want set this Image as Featured? ");
	if (r==true){
		window.location='admin.php?page=custom-'+prefix+'-images&act=featured&id='+id;
	}else{
		window.location='admin.php?page=custom-'+prefix+'-images';
	}
}
function deletCustomImage(id,prefix){
	var r=confirm("Do You Want to delete this Image?");
	if (r==true){
		window.location='admin.php?page=custom-'+prefix+'-images&act=delete&id='+id;
	}else{
		window.location='admin.php?page=custom-'+prefix+'-images';
	}
}