<?php 
/* -------------------------------- Add images Form--------------------------------------------*/
function AddImagesForm($type,$typeprefix){
global $wpdb;
	$str='<table width="50%" align="center" border="0" cellspacing="0" cellpadding="0">
<tr><td align="center"><div><h2 style="text-transform: capitalize;">New '.$typeprefix.' Image</h2></div></td></tr>
<tr>
    <td align="center">
	<form method="post" name="importLabelForm" id="importLabelForm" enctype="multipart/form-data" onsubmit="return validateForm(this)">
	<table border="0" cellspacing="0" cellpadding="0" align="center" >
	<tr>
		<td width="50%" height="10" align="left"></td>
		<td width="50%" height="10" align="left"></td>
	</tr>
	<tr>
		<td height="30" align="left"><strong style="text-transform: capitalize;">'.$typeprefix.' Title </strong></td>
	  	<td align="left"><input type="text" name="'.$typeprefix.'_title" id="'.$typeprefix.'_title" /></td>
	</tr>
	<tr>
		<td height="30" align="left"><strong style="text-transform: capitalize;">Upload '.$typeprefix.' Image </strong></td>
		<td align="left"><input name="'.$typeprefix.'_image" id="'.$typeprefix.'_image" type="file" class="required csv" value="" /></td>
	</tr>
	<tr>
		<td height="30" align="left">&nbsp;</td>
		<td align="left"><input name="'.$typeprefix.'submit" type="submit" class="button" id="button3" value="Submit" onclick="return validateForm(this)" /></td>
	</tr>
	<tr><td>&nbsp;</td></tr>
	</table>
	</form>
	</td>
</tr>
</table>';
return $str;
}

/* -------------------------------- Add images --------------------------------------------*/
function AddImages($data,$type,$typeprefix){
global $wpdb;
$upload_dir = wp_upload_dir(); 
	$mess="";
	
	if($_FILES[$typeprefix."image"]["name"] != ""){
		$ins=mysql_query("insert into ".$wpdb->prefix."custom_images (`title`, `type`, `date`) values('".addslashes($data[$typeprefix.'title'])."', '".$type."', now())");
		$recentId=mysql_insert_id();
	}else{
		$msg="You must upload the image";
	}
	if($_FILES[$typeprefix."image"]["name"] != ""){
		$ext = findexts ($_FILES[$typeprefix.'image']['name']) ;
		$ran2 = $typeprefix.$recentId.".";
		$target = $upload_dir['path'].'/';
		$basename1 = $target . $ran2.$ext; 
		$basename = $ran2.$ext; 
		move_uploaded_file($_FILES[$typeprefix.'image']['tmp_name'], $basename1);
		$sqlQuery = mysql_query("update ".$wpdb->prefix."custom_images set `image`= '".$basename."', `image_path` = '".date("/Y/m/")."' WHERE id=".$recentId);	
		//unlink($target_path);
		$basename='';
		echo "<script>window.location='admin.php?page=custom-theme-images'</script>";
	}
	if($pid !=''){
		echo "<script>window.location='admin.php?page=custom-theme-images'</script>";
	}
}
function findexts ($filename) 
 { 
 $filename = strtolower($filename) ; 
 $exts = split("[/\\.]", $filename) ; 
 $n = count($exts)-1; 
 $exts = $exts[$n]; 
 return $exts; 
 }
/* -------------------------------- get images --------------------------------------------*/ 
function getImages($type,$typeprefix){
	global $wpdb;
	$getProducts=mysql_query("select * from ".$wpdb->prefix."custom_images where type=$type order by id desc");
	$str='
	<div align="center">
	<table width="70%" align="center" border="0" cellspacing="5" cellpadding="5">
		<tr>
			<td width="40%"><strong>Title</strong></td>
			<td width="40%"><strong>Image</strong></td>
			<td width="10%"><strong>Active</strong></td>
			<td width="10%"><strong>Action</strong></td>
		</tr>';
	if(mysql_num_rows($getProducts)){
	while($fetProducts=mysql_fetch_object($getProducts)){
		if($fetProducts->status==1)
			$chk="checked=checked";
		else
			$chk="";
		$str.='
		<tr>
			<td>'.stripslashes($fetProducts->title).'</td>
			<td><img src="'.WP_CONTENT_URL. '/uploads'.$fetProducts->image_path.$fetProducts->image.'" width="100" height="50" /></td>
			<td><input type="radio" name="'.$typeprefix.'_featured" id="'.$typeprefix.'_featured" '.$chk.' onclick="setAsFeatured('.$fetProducts->id.')" /></td>
			<td>'; 
			if($fetProducts->status <>1)
				$str.='<div onclick="deletCustomImage('.$fetProducts->id.')">Delete</div>';
			$str.='</td>
		</tr>';
	}
	}
$str.='  
</table>
</div>';
return $str;
}
/* -------------------------------- Delete images --------------------------------------------*/
function deleteCustomImage($id){
	global $wpdb;
	$delProducts=mysql_query("delete from ".$wpdb->prefix."custom_images where id=".$id);
	echo "<script>window.location='admin.php?page=custom-theme-images'</script>";
}
/* -------------------------------- Set as Featured images --------------------------------------------*/
function setasFeaturedImage($id){
	global $wpdb;
	$getIdVal=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."custom_images where id=$id"));
	$unsetfeatured=mysql_query("update ".$wpdb->prefix."custom_images set status='' where type=$getIdVal->type");
	$setfeatured=mysql_query("update ".$wpdb->prefix."custom_images set status=1 where id=".$id);
	echo "<script>window.location='admin.php?page=custom-theme-images'</script>";
}
/* -------------------------------- Get Featured Single image --------------------------------------------*/
function getcustomImage($type){
	global $wpdb;
	$fetCustomImage=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."custom_images where type=$type and status=1"));
	if($fetCustomImage)
		$finalimg=WP_CONTENT_URL. '/uploads'.$fetCustomImage->image_path.$fetCustomImage->image;
	else
		$finalimg='';
	return $finalimg;
}
/* -------------------------------- Set as Featured Color --------------------------------------------*/
function setasFeaturedColor($id){
	global $wpdb;
	$unsetcolor=mysql_query("update ".$wpdb->prefix."custom_colors set status=''");
	$setfeaturedcolor=mysql_query("update ".$wpdb->prefix."custom_colors set status=1 where id=".$id);
	echo "<script>window.location='admin.php?page=theme-options'</script>";
}
/* -------------------------------- get Color Options --------------------------------------------*/
function getColorOptions(){
	global $wpdb;
	$getColors=mysql_query("select * from ".$wpdb->prefix."custom_colors");
	$str= '
	<table class="theme-options-table" width="50%" border="0" cellpadding="0" cellspacing="0" style="border:1px solid #ccc">
  	<tr><td colspan="3" bgcolor="#CCCCCC"><h2>Color Options </h2></td></tr>';
	while($fetColors=mysql_fetch_object($getColors)){
  		if($fetColors->status==1)
			$chk="checked=checked";
		else
			$chk="";
	$str.='<tr>
    	<td>'.$fetColors->title.'</td>
	    <td><input type="radio" onclick="setThisColor('.$fetColors->id.')" '.$chk.' name="color_option" /></td>
    	<td><input type="button" name="'.$fetColors->title.'" width="20" style=" width:20px;background:'.$fetColors->color.'" readonly="" /></td>
	  </tr>
	  <tr><td colspan="3"></td></tr>';
   	}
	$str.='</table>';
	return $str;
}

/* -------------------------------- Get Contact text Form --------------------------------------------*/
function getContactFormText($type,$id){
	global $wpdb;
	$fetabt=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."custom_contacts where id=$id"));
$str='<form method="post">
<table>
	<tr><td height="70"><strong>Content</strong></td><td><input type="text" name="'.$type.'" value="'.stripslashes($fetabt->content).'"/></td><td><input type="submit" value="submit" name="'.$type.'submit" />
	</td></tr>
</table>
</form>';
return $str;
}
/* -------------------------------- Get Contact textarea Form --------------------------------------------*/
function getContactFormTextArea($type,$id){
	global $wpdb;
	$fetabt=mysql_fetch_object(mysql_query("select * from ".$wpdb->prefix."custom_contacts where id=$id"));
$str='<form method="post">
<table>
	<tr><td height="70"><strong>Content</strong></td><td><textarea cols="50" rows="3" name="'.$type.'" >'.stripslashes($fetabt->content).'</textarea></td><td><input type="submit" value="submit" name="'.$type.'submit" />
	</td></tr>
</table>
</form>';
return $str;
}
/* -------------------------------- Update Contact Form --------------------------------------------*/
function updateContactForm($data,$type,$id){
	global $wpdb;
	$updabout=mysql_query("update ".$wpdb->prefix."custom_contacts set content='".addslashes($data[$type])."' where id=$id");
	echo "<script>window.location='admin.php?page=theme-options'</script>";
}
/* -------------------------------- Get Testimonial Form ---------------------------------------------------*/
function getTestimonialForm(){
	$str='<table width="50%" align="center" border="0" cellspacing="0" cellpadding="0">
<tr><td align="center"><div><h2>New Testimonial</h2></div></td></tr>
<tr>
    <td align="center">
	<form method="post" name="importLabelForm" id="importLabelForm" enctype="multipart/form-data" onsubmit="return validateForm(this)">
	<table border="0" cellspacing="0" cellpadding="0" align="center" >
	<tr>
		<td width="50%" height="10" align="left"></td>
		<td width="50%" height="10" align="left"></td>
	</tr>
	<tr>
		<td height="30" align="left"><strong>Name </strong></td>
	  	<td align="left"><input type="text" name="testimonial_name" id="header_title" /></td>
	</tr>
	<tr>
		<td height="30" align="left"><strong>City </strong></td>
	  	<td align="left"><input type="text" name="testimonial_city" id="header_title" /></td>
	</tr>
	<tr>
		<td height="30" align="left"><strong>Content </strong></td>
		<td align="left"><textarea name="testimonial_desc" rows="5" cols="30" ></textarea></td>
	</tr>
	<tr>
		<td height="30" align="left">&nbsp;</td>
		<td align="left"><input name="testimonialsubmit" type="submit" class="button" id="button3" value="Submit" onclick="return validateForm(this)" /></td>
	</tr>
	<tr><td>&nbsp;</td></tr>
	</table>
	</form>
	</td>
</tr>
</table>';
return $str;
}
/* -------------------------------- AddTestimonial ---------------------------------------------------*/
function AddTestimonial($data){
	global $wpdb;
	$ins=mysql_query("insert into ".$wpdb->prefix."custom_testimonials (`name`, `city`, `content`, `date`) values ('".addslashes($data['testimonial_name'])."', '".addslashes($data['testimonial_city'])."', '".addslashes($data['testimonial_desc'])."', now())");
	echo "<script>window.location='admin.php?page=custom-theme-testimonials'</script>";
}
/* -------------------------------- get Testimonials ---------------------------------------------------*/
function getTestimonials(){
	global $wpdb;
	$getTestimonials=mysql_query("select * from ".$wpdb->prefix."custom_testimonials order by date desc");
	$str= '
	<table width="70%" border="0" cellpadding="0" cellspacing="0" align="center">
  	<tr>
		<td height="30" align="center"><strong>Name</strong></td>
		<td align="center"><strong>City</strong></td>
		<td align="center"><strong>Content</strong></td>
		<td width="10%" align="center"><strong>Action</strong></td>
	</tr>';
	
	while($fetTestimonials=mysql_fetch_object($getTestimonials)){
  		
	$str.='<tr>
    	<td width="10%">'.$fetTestimonials->name.'</td>
	    <td width="10%">'.$fetTestimonials->city.'</td>
    	<td width="70%"><div style="padding:0px 10px;">'.$fetTestimonials->content.'</div></td>
		<td width="10%"><div onclick="deleteCustomTestimonial('.$fetTestimonials->id.')">Delete</div></td>
	  </tr>
	  <tr><td colspan="3">&nbsp;</td></tr>';
   	}
	$str.='<tr><td colspan="4">&nbsp;</td></tr></table>';
	return $str;
}
/*-------------------------------------Delete Testimonials ---------------------------------------*/
function deleteCustomTestimonial($id){
	global $wpdb;
	$delTestimonial=mysql_query("delete from ".$wpdb->prefix."custom_testimonials where id=".$id);
	echo "<script>window.location='admin.php?page=custom-theme-testimonials'</script>";
	
}
?>

